const excuses = [
  "my wifi stopped believing in me",
  "i blinked and suddenly it was 3 hours later",
  "my computer updated at the worst possible time",
  "i was going to do it but then i didn't",
  "time moved weirdly today idk",
  "i opened the app and immediately forgot why",
  "something went wrong but like… emotionally",
  "i got distracted by literally nothing",
  "it was a whole situation",
  "don't worry about it 👍"
];

document.getElementById("btn").addEventListener("click", () => {
  const pick = excuses[Math.floor(Math.random() * excuses.length)];
  document.getElementById("out").textContent = pick;
});